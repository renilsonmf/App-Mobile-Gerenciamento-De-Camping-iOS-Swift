# CommonsService

[![CI Status](https://img.shields.io/travis/leticiassiqueira25/CommonsService.svg?style=flat)](https://travis-ci.org/leticiassiqueira25/CommonsService)
[![Version](https://img.shields.io/cocoapods/v/CommonsService.svg?style=flat)](https://cocoapods.org/pods/CommonsService)
[![License](https://img.shields.io/cocoapods/l/CommonsService.svg?style=flat)](https://cocoapods.org/pods/CommonsService)
[![Platform](https://img.shields.io/cocoapods/p/CommonsService.svg?style=flat)](https://cocoapods.org/pods/CommonsService)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

CommonsService is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'CommonsService'
```

## Author

leticiassiqueira25, leticiassiqueira25@gmail.com

## License

CommonsService is available under the MIT license. See the LICENSE file for more info.
